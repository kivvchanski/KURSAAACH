package com.example.kursachyouknow;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.kursachyouknow.databinding.ActivityHomePageBinding;
import com.example.kursachyouknow.databinding.ActivityMainBinding;
import com.example.kursachyouknow.databinding.ActivityReadBookBinding;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ReadBook extends AppCompatActivity {
    private TextView textView;
    private Button backBtn;
    private Button nextBtn, closeBtn;

    private List<String> pages;
    private int currentPage = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_book);
        textView = findViewById(R.id.bookPage);
        backBtn = findViewById(R.id.btnBackPage);
        nextBtn = findViewById(R.id.btnNextPage);
        closeBtn = findViewById(R.id.btnBackRead);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        try {
            InputStream inputStream = getResources().openRawResource(R.raw.sample_text);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder text = new StringBuilder();
            String line = reader.readLine();
            while (line != null) {
                text.append(line).append("\n");
                line = reader.readLine();
            }
            reader.close();
            inputStream.close();
            String fullText = text.toString();
            pages = splitStringIntoPages(fullText, 34, 25);

            displayPage(currentPage);
        } catch (IOException e) {
            e.printStackTrace();
        }

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentPage > 0) {
                    currentPage--;
                    displayPage(currentPage);
                }
            }
        });

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentPage < pages.size() - 1) {
                    currentPage++;
                    displayPage(currentPage);
                }
            }
        });
    }

    private void displayPage(int page) {
        textView.setText(pages.get(page));
    }
    public static List<String> splitStringIntoPages(String input, int maxLineLength, int maxLinesPerPage) {
        List<String> result = new ArrayList<>();

        String[] words = input.split(" ");
        StringBuilder page = new StringBuilder();
        int lines = 0;

        for (String word : words) {
            if ((page.length() + word.length() + 1) > maxLineLength && lines == maxLinesPerPage) {
                result.add(page.toString());
                page = new StringBuilder();
                lines = 0;
            }

            if (page.length() > 0) {
                page.append(" ");
            }
            page.append(word);

            lines++;
        }

        if (page.length() > 0) {
            result.add(page.toString());
        }

        return result;
    }
}