package com.example.kursachyouknow;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.kursachyouknow.databinding.ActivityMenuBinding;

import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {
ActivityMenuBinding binding;
ArrayList<Intent> intent2;
String back, login;
String[] elems= {"Книги", "Информация об авторе", "Информация о приложении", "Выйти из профиля", "Выйти"};
ListView LvMain;
private Toolbar mToolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMenuBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        LvMain = (ListView) findViewById(R.id.lvMain);
        binding.btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            finish();
            }
        });
        fillIntents();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.menu_elem, elems);
        LvMain.setAdapter(adapter);

        LvMain.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position != 4) {
                    startActivity(intent2.get(position));
                }
                else {
                    finishAffinity();
                }
            }
        });
        login = getIntent().getStringExtra("login");


    }


    private void fillIntents() {
        intent2 = new ArrayList<>();
        intent2.add(new Intent(this, HomePage.class));
        intent2.add(new Intent(this, AuthorInfo.class));
        intent2.add(new Intent(this, BookInfo.class));
        intent2.add(new Intent(this, MainActivity.class));
    }

}