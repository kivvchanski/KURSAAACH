package com.example.kursachyouknow;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.os.Environment;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kursachyouknow.databinding.ActivityBookInfoBinding;

public class BookInfo extends AppCompatActivity {
ActivityBookInfoBinding binding;
String login;
private Toolbar toolbar;
Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBookInfoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        intent = new Intent(this, MenuActivity.class);
        intent.putExtra("login", login);
        Intent intent2 = new Intent(this, ReadBook.class);
        intent2.putExtra("from", "HomePage");
        binding.btnMenuBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
        binding.toRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent2);
            }
        });
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("Ваши книги");
        login = getIntent().getStringExtra("login");
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.about_app2) {
            Intent newintent = new Intent(this, BookInfo.class);
            newintent.putExtra("login", login);
            startActivity(newintent);
            return true;
        }
        else if (id == R.id.about_user2) {
            Intent newintent = new Intent(this, AuthorInfo.class);
            newintent.putExtra("login", login);
            startActivity(newintent);
            return true;
        }
        else if (id == R.id.menu_option2) {
            Intent newintent = new Intent(this, MenuActivity.class);
            newintent.putExtra("login", login);
            startActivity(newintent);
            return true;
        }
        else{
            return false;
        }
    }
}