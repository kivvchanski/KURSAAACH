package com.example.kursachyouknow;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kursachyouknow.databinding.ActivityHomePageBinding;

import org.json.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class HomePage extends AppCompatActivity {
ActivityHomePageBinding binding;
    String login;
    private Toolbar toolbar;
    ArrayList<Book> elems = new ArrayList<>();
    Intent intent;
    ListView lvMain;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomePageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        intent = new Intent(this, MenuActivity.class);
        intent.putExtra("from", "HomePage");
        binding.btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
        NeFullStrashilka();
        lvMain = binding.listView;
        AnimeAdapter adapter = new AnimeAdapter(this, elems);
        lvMain.setAdapter(adapter);
        int imageId = getResources().getIdentifier("pic1",
                "drawable", "com.example.kursachyouknow");
        Book book = new Book("Title", "Author", "Path/to/file.txt", "description", imageId);
        saveBookListToJson();
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("Ваши книги");
        login = getIntent().getStringExtra("login");

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.about_app2) {
            Intent newintent = new Intent(this, BookInfo.class);
            newintent.putExtra("login", login);
            startActivity(newintent);
            return true;
        }
        else if (id == R.id.about_user2) {
            Intent newintent = new Intent(this, AuthorInfo.class);
            newintent.putExtra("login", login);
            startActivity(newintent);
            return true;
        }
        else if (id == R.id.menu_option2) {
            Intent newintent = new Intent(this, MenuActivity.class);
            newintent.putExtra("login", login);
            startActivity(newintent);
            return true;
        }
        else{
            return false;
        }
    }

    private void fullStrahilka() {
        if(Environment.getExternalStorageState()
                .equals(Environment.MEDIA_MOUNTED)) {
            File kNIGGA = new File(getExternalFilesDir(null), "book.txt");
        }
    }
    private void NeFullStrashilka() {
        String[] names = {"Kniga1", "Kniga2", "Kniga3", "Kniga4", "Kniga5", "Kniga6"};
        String[] authors = {"Big boy", "Bogatir", "Back window", "Iren men", "John Wheat"};
        String[] janr = {"full Strashilka", "full Strashilka", "full Strashilka","full Strashilka","full Strashilka"};
        for (int i = 1; i <= 5; i++) {
            String a = Integer.toString(i);
            int imageId = getResources().getIdentifier("pic" + a,
                    "drawable", "com.example.kursachyouknow");
            elems.add(new Book(names[i-1], authors[i-1],"path", janr[i-1],  imageId));
        }
    }
    private void saveBookListToJson() {
        JSONArray jsonArray = new JSONArray();

        for (Book book : elems) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("title", book.name);
                jsonObject.put("author", book.author);
                jsonObject.put("filepath", book.path);
                jsonObject.put("description", book.description);
                jsonArray.put(jsonObject);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        String jsonString = jsonArray.toString();

        try {
            File file = new File(getFilesDir(), "books.json");
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(jsonString);
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}