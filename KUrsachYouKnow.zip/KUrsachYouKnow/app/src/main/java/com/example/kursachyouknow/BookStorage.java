package com.example.kursachyouknow;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class BookStorage {

    private static final String PREFS_NAME = "BookPrefs";
    private static final String BOOKS_KEY = "Books";

    public static void saveBooks(Context context, ArrayList<Book> books) {
        SharedPreferences.Editor editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        Gson gson = new Gson();
        String json = gson.toJson(books);
        editor.putString(BOOKS_KEY, json);
        editor.apply();
    }

    public static ArrayList<Book> loadBooks(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Gson gson = new Gson();
        String json = prefs.getString(BOOKS_KEY, null);
        Type type = new TypeToken<ArrayList<Book>>() {}.getType();
        return gson.fromJson(json, type);
    }
}