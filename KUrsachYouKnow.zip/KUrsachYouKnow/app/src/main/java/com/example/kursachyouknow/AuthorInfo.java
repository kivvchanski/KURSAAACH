package com.example.kursachyouknow;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import com.example.kursachyouknow.databinding.ActivityAuthorInfoBinding;

public class AuthorInfo extends AppCompatActivity {
ActivityAuthorInfoBinding binding;
Button btnMenu;
String login;
Intent intent;
private Toolbar mToolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAuthorInfoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initViews();
        intent = new Intent(this, MenuActivity.class);
        intent.putExtra("from", "HomePage");
        binding.btnMenuAuthor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
        mToolbar = findViewById(R.id.toolbar3);
        setSupportActionBar(mToolbar);
        login = getIntent().getStringExtra("login");
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.toolbar_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.about_app2) {
            Intent newintent = new Intent(this, BookInfo.class);
            newintent.putExtra("login", login);
            startActivity(newintent);
            return true;
        }
        else if (id == R.id.about_user2) {
            Intent newintent = new Intent(this, AuthorInfo.class);
            newintent.putExtra("login", login);
            startActivity(newintent);
            return true;
        }
        else if (id == R.id.menu_option2) {
            Intent newintent = new Intent(this, MenuActivity.class);
            newintent.putExtra("login", login);
            startActivity(newintent);
            return true;
        }
        else{
            return false;
        }
    }
    private void initViews() {
        intent = new Intent(this, MenuActivity.class);
        btnMenu = findViewById(R.id.btnMenuAuthor);
        binding.imageView.setImageResource(R.drawable.some_human);
        binding.bioAuthor.setText(R.string.aboutme);

    }


}