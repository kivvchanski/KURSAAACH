package com.example.kursachyouknow;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AnimeAdapter extends BaseAdapter {
    Context ctx;
    LayoutInflater ltInflater;
    ArrayList<Book> objects;

    AnimeAdapter(Context context, ArrayList<Book> Books) {
        ctx = context;
        objects = Books;
        ltInflater = (LayoutInflater)
                ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return objects.size();
    }

    @Override
    public Object getItem(int position) {
        return objects.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null)
            view = ltInflater.inflate(R.layout.book_elem, parent, false);

        Book p = getBook(position);

        ((TextView) view.findViewById(R.id.tvName)).setText("Название:" + p.name);
        ((TextView) view.findViewById(R.id.tvAuthor)).setText("Автор книги: " + p.author);
        ((TextView) view.findViewById(R.id.tvJanr)).setText("Жанр: " + p.description);
        ((ImageView) view.findViewById(R.id.ivImage)).setImageResource(p.image);


        return view;
    }

    Book getBook(int position)
    {
        return ((Book) getItem(position));
    }
    public interface OnItemClickListener {
        void onItemClick(Book book);
    }

    private OnItemClickListener listener;

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView bookTitle;
        private ImageView bookCover;

        @SuppressLint("ResourceType")
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            bookTitle = itemView.findViewById(R.id.tvName);
            bookCover = itemView.findViewById(R.drawable.app_icon);


            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            if (position != RecyclerView.NO_POSITION) {
                Book clickedBook = objects.get(position);
                listener.onItemClick(clickedBook);
            }
        }
    }
}
