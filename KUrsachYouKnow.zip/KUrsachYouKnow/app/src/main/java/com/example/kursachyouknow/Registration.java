package com.example.kursachyouknow;


import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.example.kursachyouknow.databinding.ActivityMainBinding;
import com.example.kursachyouknow.databinding.ActivityRegistrationBinding;

public class Registration extends AppCompatActivity {
    ActivityRegistrationBinding binding2;
    Intent outIntent, newIntent;
    Button btnReg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding2 = ActivityRegistrationBinding.inflate(getLayoutInflater());
        outIntent = getIntent();
        setContentView(binding2.getRoot());
        btnReg = findViewById(R.id.btnReg);
        if (outIntent.getStringExtra("type").equals("login")) {
            findViewById(R.id.editName).setVisibility(View.INVISIBLE);
            btnReg.setText("Войти");
        }
        if (outIntent.getStringExtra("type").equals("reg")) {
            findViewById(R.id.editName).setVisibility(View.VISIBLE);
            btnReg.setText("Зарегистрироваться");
        }
        newIntent = new Intent(this, HomePage.class);
        binding2.btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (outIntent.getStringExtra("type").equals("login")) {
                    login();
                }
                else {
                    registration();
                }
            }
        });

    }
    String loginText, passwordText;
    DatabaseHelper dbHelper = new DatabaseHelper(this);
    private void login() {

        loginText = binding2.editEmail.getText().toString();
        passwordText = binding2.editPassword.getText().toString();
        if (dbHelper.checkUser(loginText, passwordText)) {
            startActivity(newIntent);
        }
        else {
            Toast.makeText(this, "Неверные данные", Toast.LENGTH_SHORT).show();
        }
    }
    String name;
    private void registration() {
        name = binding2.editName.getText().toString();
        loginText = binding2.editEmail.getText().toString();
        passwordText = binding2.editPassword.getText().toString();
        if (!loginText.equals("")) {
            if (!dbHelper.checkUsernameExists(loginText)) {
                name = binding2.editName.getText().toString();
                if (loginText.startsWith("adm")) {
                    dbHelper.saveInfo(loginText, passwordText, name, "Admin");
                } else if (loginText.startsWith("wr")) {
                    dbHelper.saveInfo(loginText, passwordText, name, "Writer");
                } else {
                    dbHelper.saveInfo(loginText, passwordText, name, "User");
                }

                newIntent.putExtra("user", loginText);
                startActivity(newIntent);
            }
            else {
                Toast.makeText(this, "Ошибка! Пользователь с такой почтой уже существует!", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(this, "Ошибка! Какое-то поле пустое!", Toast.LENGTH_SHORT).show();
        }


    }

}