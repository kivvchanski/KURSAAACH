package com.example.kursachyouknow;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Book implements Parcelable {
    String author;
    String name, path, description;
    String janr;
    int image;


    Book(String name, String author, String path, String desc, int image) {;
        this.name = name;
        this.author = author;
        this.path = path;
        this.description = desc;
        this.image = image;

    }

    Book(Parcel parcel) {
        name = parcel.readString();
        author = parcel.readString();
        janr = parcel.readString();
        image = parcel.readInt();

    }

    public static final Parcelable.Creator<Book> CREATOR = new Parcelable.Creator<Book>() {
        @Override
        public Book createFromParcel(Parcel in) {
            return new Book(in);
        }

        @Override
        public Book[] newArray(int size) {
            return new Book[size];
        }
    };


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(author);
        dest.writeString(janr);
        dest.writeInt(image);

    }
}
